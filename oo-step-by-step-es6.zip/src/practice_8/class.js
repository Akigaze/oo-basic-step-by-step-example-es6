
module.exports = class Class {
    constructor(number) {
        this.number = number;
    }


    getDisplayName() {
        return `Class ${this.number}`
    }

    equal(klass) {
        return this.number == klass.number;
    }

    assignLeader(leader){
        // this.number === leader.klass.number
        if(this.equal(leader.klass)){
            this.leader = leader;
        }
    }

    verifyLeader(student){
        return this.leader !== undefined && this.leader.is(student);
    }
}
