
const Person = require("./person.js")
module.exports = class Teacher extends Person {
    constructor(id, name, age, klass) {
        super(id, name, age);
        this.klass = klass;
    }

    basicIntroduce() {
        return `${super.introduce()} I am a Teacher.`;
    }

    introduce() {
        const klassString = (this.klass === undefined) ? "No Class" : `${this.klass.getDisplayName()}`;

        return `${this.basicIntroduce()} I teach ${klassString}.`;
    }

    introduceWith(student) {
        let teachString = `I don't teach ${student.name}`;
        if (this.klass.equal(student.klass)) {
            teachString = `I teach ${student.name}`;
        }

        return `${this.basicIntroduce()} ${teachString}.`
    }
}

