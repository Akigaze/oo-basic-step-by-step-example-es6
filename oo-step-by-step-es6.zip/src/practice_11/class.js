
module.exports = class Class {
    constructor(number) {
        this.number = number;
        this.members = [];
        this.leaderAssignedListeners = [];
        this.joinListeners = [];
    }


    getDisplayName() {
        return `Class ${this.number}`
    }

    equal(klass) {
        return this.number == klass.number;
    }

    assignLeader(leader) {
        if (this.equal(leader.klass)) {
            this.leader = leader;
            this._notifyLeaderAssigned(leader);
        } else {
            console.log("It is not one of us.")
        }
    }

    verifyLeader(student) {
        return this.leader !== undefined && this.leader.is(student);
    }

    appendMember(student) {
        student.changeClass(this);
        this.members.push(student);
        this._nofiyJoined(student);
    }

    registerAssignLeaderListener(listener){
        this.leaderAssignedListeners.push(listener);
    }

    _notifyLeaderAssigned(leader){
        this.leaderAssignedListeners.forEach(listener => listener.nofityLeaderAssigned(leader, this));
    }

    registerJoinListener(listener){
        this.joinListeners.push(listener);
    }

    _nofiyJoined(student) {
        this.joinListeners.forEach(listener => listener.nofiyJoined(student, this));
    }
}
