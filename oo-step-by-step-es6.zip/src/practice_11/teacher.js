

const Person = require("./person.js")
module.exports = class Teacher extends Person {
    constructor(id, name, age, klasses) {
        super(id, name, age);
        this.klasses = klasses;
    }

    basicIntroduce() {
        return `${super.introduce()} I am a Teacher.`;
    }

    introduce() {
        const klassString = (this.klasses === undefined || this.klasses.length === 0)
            ? "No Class"
            : `Class ${this.klasses.map(x => x.number).join(", ")}`;

        return `${this.basicIntroduce()} I teach ${klassString}.`;
    }

    introduceWith(student) {
        let teachString = `I don't teach ${student.name}`;
        if (this.klasses.find((x) => x.equal(student.klass)) !== undefined) {
            teachString = `I teach ${student.name}`;
        }

        return `${this.basicIntroduce()} ${teachString}.`
    }

    nofityLeaderAssigned(leader, klass){
        console.log(`I am ${this.name}. I know ${leader.name} become Leader of ${klass.getDisplayName()}.`)
    }

    nofiyJoined(student, klass){
        console.log(`I am ${this.name}. I know ${student.name} has joined ${klass.getDisplayName()}.`);
    }
}

