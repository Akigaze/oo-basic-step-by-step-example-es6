
module.exports = class Class {
    constructor(number) {
        this.number = number;
    }


    getDisplayName() {
        return `Class ${this.number}`
    }

    equal(klass) {
        return this.number == klass.number;
    }
}
