
module.exports = class Class {
    constructor(number) {
        this.number = number;
        this.members = [];
    }


    getDisplayName() {
        return `Class ${this.number}`
    }

    equal(klass) {
        return this.number == klass.number;
    }

    assignLeader(leader) {
        if (this.equal(leader.klass)) {
            this.leader = leader;
        } else {
            console.log("It is not one of us.")
        }
    }

    verifyLeader(student) {
        return this.leader !== undefined && this.leader.is(student);
    }

    appendMember(student) {
        student.changeClass(this);
        this.members.push(student);
    }
}
