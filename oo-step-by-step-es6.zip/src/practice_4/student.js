
const Person = require("./person.js")
module.exports = class Students extends Person {
    constructor(name, age, klass) {
        super(name, age);
        this.klass = klass;
    }

    introduce() {
        return `${super.basic_introduce()} I am a Student. I am at Class ${this.klass}.`
    }
}

