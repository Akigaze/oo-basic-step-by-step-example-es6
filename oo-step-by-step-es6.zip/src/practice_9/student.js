
const Person = require("./person.js")
module.exports = class Students extends Person {
    constructor(id, name, age, klass) {
        super(id, name, age);
        this.klass = klass;
    }

    is(student) {
        return this.id == student.id;
    }

    introduce() {
        let klassString = this.klass.verifyLeader(this)
            ? `I am Leader of ${this.klass.getDisplayName()}.`
            : `I am at ${this.klass.getDisplayName()}.`;

        return `${super.introduce()} I am a Student. ${klassString}`;
    }

    changeClass(klass){
        this.klass = klass;
    }
}

